package com.safran.ads.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safran.ads.entities.Kit;
import com.safran.ads.model.MessageResponse;
import com.safran.ads.repositories.KitRepositories;
import com.safran.ads.services.KitServices;

@Service
public class KitServicesImpl implements KitServices{

	@Autowired
	private KitRepositories kitRep;
	
	@Override
	public MessageResponse save(Kit kit) {
		
		boolean exist= kitRep.existsByProductAndOef(kit.getProduct(), kit.getOef());
		if(exist) {
			return new MessageResponse(false, "DEMANDE EXISTENT!!!");
		}
		kitRep.save(kit);
		return new MessageResponse(true, "DEMANDE KIT EFFECTUER AVEC SUCCESS");
	
	}

	@Override
	public MessageResponse update(Kit kit) {
		kitRep.save(kit);
		return new MessageResponse(true, "MODIFICATION EFFECTUER AVEC SUCCESS");
	}

	@Override
	public MessageResponse delete(Integer id) {
		boolean exist = kitRep.existsById(id);
		if (!exist) {
			return new MessageResponse(false, "KIT not found");
		}
		kitRep.deleteById(id);
		return new MessageResponse(true, "Suppression effectué avec succés");
	}

	@Override
	public List<Kit> findAll() {
		// TODO Auto-generated method stub
		return kitRep.findAll();
	}

	@Override
	public List<Kit> findByEtats(String etats) {
		// TODO Auto-generated method stub
		return kitRep.findByEtats(etats);
	}

	@Override
	public List<Kit> findByProductAndOef(String product, String oef) {
		// TODO Auto-generated method stub
		return kitRep.findByProductAndOef(product, oef);
	}

	@Override
	public Kit findById(Integer id) {
		// TODO Auto-generated method stub
		return  kitRep.findById(id).orElse(null);
	}

	@Override
	public List<Kit> findByIlots(String ilots) {
		// TODO Auto-generated method stub
		return kitRep.findByIlots(ilots);
	}

}
