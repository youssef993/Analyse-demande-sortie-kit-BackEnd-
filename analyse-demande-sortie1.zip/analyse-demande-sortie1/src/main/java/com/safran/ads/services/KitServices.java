package com.safran.ads.services;

import java.util.List;

import com.safran.ads.entities.Kit;
import com.safran.ads.model.MessageResponse;

public interface KitServices {
	public MessageResponse save(Kit kit);
	public MessageResponse update(Kit kit);
	public MessageResponse delete(Integer id);
	public List<Kit> findAll();
	public List<Kit> findByEtats(String etats);
	public List<Kit> findByProductAndOef(String product, String oef);
	public List<Kit> findByIlots(String ilots);
	public Kit findById(Integer id);

}
