package com.safran.ads.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.safran.ads.entities.Produits;
import com.safran.ads.entities.Profiles;
import com.safran.ads.model.MessageResponse;
import com.safran.ads.services.ProduitsServices;

@RestController
@CrossOrigin("*")
@RequestMapping("/produit")
public class ProduitsControllers {
	
	@Autowired
	private ProduitsServices produitService;

	@PreAuthorize("hasAnyRole('ROLE_Admin','ROLE_User','ROLE_Validateur','ROLE_Realisateur')")
	@GetMapping
	public List<Produits> getAll(){
		return produitService.findAll();
				}
	@PreAuthorize("hasAnyRole('ROLE_Admin','ROLE_User','ROLE_Validateur','ROLE_Realisateur')")
	@PutMapping
	public MessageResponse edit(@RequestBody Produits produit) {
		return produitService.update(produit);
	}
	@PreAuthorize("hasAnyRole('ROLE_Admin','ROLE_User')")
	@PostMapping
	public MessageResponse add(@RequestBody Produits produit) {
		return produitService.save(produit);
	}
	@PreAuthorize("hasRole('ROLE_Admin')")
	@DeleteMapping("/{id}")
	public MessageResponse Delete(@PathVariable Integer id) {
		return produitService.delete(id);
	}
	@PreAuthorize("hasAnyRole('ROLE_Admin','ROLE_User','ROLE_Validateur','ROLE_Realisateur')")
	@GetMapping("/{id}")
	public Produits getById(@PathVariable Integer id){
		return produitService.findById(id);
	}
	@PreAuthorize("hasAnyRole('ROLE_Admin','ROLE_User','ROLE_Validateur','ROLE_Realisateur')")
	@GetMapping("/{produit}/{of}")
	public List<Produits> getByProduitAndOf(@PathVariable("produit") String produit, @PathVariable("of") String of){
		return produitService.findByProduitAndOf(produit, of);
		
	}
	@PreAuthorize("hasAnyRole('ROLE_Admin','ROLE_User','ROLE_Validateur','ROLE_Realisateur')")
	@GetMapping("/Produits/{ilot}")
	public List<Produits> getByIlot(@PathVariable("ilot") String ilot){
		return produitService.findByIlot(ilot);
	}
	@PreAuthorize("hasAnyRole('ROLE_Admin','ROLE_User','ROLE_Validateur','ROLE_Realisateur')")
	@GetMapping("/Prod/{etat}")
	public List<Produits> getByEtat(@PathVariable("etat") String etat){
		return produitService.findByEtat(etat);
	}
}
