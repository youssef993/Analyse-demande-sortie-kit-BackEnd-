package com.safran.ads.services;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.safran.ads.entities.Profiles;
import com.safran.ads.model.MessageResponse;

public interface ProfilesServices extends UserDetailsService  {
	
	public MessageResponse save(Profiles profile);
	public MessageResponse update(Profiles profile);
	public MessageResponse delete(Integer id);
	public List<Profiles> findAll();
	public Profiles findById(Integer id);

}
