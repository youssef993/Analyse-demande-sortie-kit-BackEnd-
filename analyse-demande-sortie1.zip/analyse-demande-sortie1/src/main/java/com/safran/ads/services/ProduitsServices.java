package com.safran.ads.services;

import java.util.List;

import com.safran.ads.entities.Produits;
import com.safran.ads.model.MessageResponse;

public interface ProduitsServices {
	public MessageResponse save(Produits produit);
	public MessageResponse update(Produits produit);
	public MessageResponse delete(Integer id);
	public List<Produits> findAll();
	public List<Produits> findByProduitAndOf(String prod, String of);
	public List<Produits> findByIlot(String ilot);
	public List<Produits> findByEtat(String etat);
	public Produits findById(Integer id);

}
