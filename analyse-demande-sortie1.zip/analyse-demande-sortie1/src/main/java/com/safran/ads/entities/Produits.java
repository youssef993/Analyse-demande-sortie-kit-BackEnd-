package com.safran.ads.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Produits implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String ilot;
	private String produit;
	private String of;
	private String composant;
	private String numLot;
	private String impt;
	private String date;
	private String etat;
	private String numLotS;
	private String cause;

}
