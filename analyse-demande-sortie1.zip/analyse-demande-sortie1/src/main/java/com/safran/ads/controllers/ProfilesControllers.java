package com.safran.ads.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.safran.ads.entities.Profiles;
import com.safran.ads.model.MessageResponse;
import com.safran.ads.services.ProfilesServices;


@RestController
@CrossOrigin("*")
@RequestMapping("/profile")
public class ProfilesControllers {
	
	@Autowired
	private ProfilesServices profileService;
	
	@PreAuthorize("hasRole('ROLE_Admin')")
	@GetMapping
	public List<Profiles> getAll(){
		return profileService.findAll();
	}
	@PreAuthorize("hasRole('ROLE_Admin')")
	@PutMapping
	public MessageResponse edit(@RequestBody Profiles profile) {
		return profileService.update(profile);
	}
	@PreAuthorize("hasRole('ROLE_Admin')")
	@PostMapping
	public MessageResponse add(@RequestBody Profiles profile) {
		return profileService.save(profile);
	}
	@PreAuthorize("hasAnyRole('ROLE_Admin')")
	@DeleteMapping("/{id}")
	public MessageResponse Delete(@PathVariable Integer id) {
		return profileService.delete(id);
	}
	@PreAuthorize("hasRole('ROLE_Admin')")
	@GetMapping("/{id}")
	public Profiles getById(@PathVariable Integer id) {
		return profileService.findById(id);
	}

}
