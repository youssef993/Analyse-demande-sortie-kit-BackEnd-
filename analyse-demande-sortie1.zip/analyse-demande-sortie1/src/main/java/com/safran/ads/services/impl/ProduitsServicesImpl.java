package com.safran.ads.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.safran.ads.entities.Produits;
import com.safran.ads.model.MessageResponse;
import com.safran.ads.repositories.ProduitsRepositories;
import com.safran.ads.services.ProduitsServices;

@Service
public class ProduitsServicesImpl implements ProduitsServices {

	@Autowired
	private ProduitsRepositories produitRep;
	@Override
	public MessageResponse save(Produits produit) {
		boolean exist= produitRep.existsByProduitAndOfAndComposant(produit.getProduit(),produit.getOf(),produit.getComposant());
		if(exist) {
			return new MessageResponse(false, "DEMANDE EXISTENT!!!");
		}
		produitRep.save(produit);
		return new MessageResponse(true, "DEMANDE EFFECTUER AVEC SUCCESS");
	}

	@Override
	public MessageResponse update(Produits produit) {
		produitRep.save(produit);
		return new MessageResponse(true, "MODIFICATION EFFECTUER AVEC SUCCESS");
	}

	@Override
	public MessageResponse delete(Integer id) {
		boolean exist = produitRep.existsById(id);
		if (!exist) {
			return new MessageResponse(false, "user not found");
		}
		produitRep.deleteById(id);
		return new MessageResponse(true, "Suppression effectué avec succés");
	}

	@Override
	public List<Produits> findAll() {
		// TODO Auto-generated method stub
		return produitRep.findAll();
	}

	@Override
	public List<Produits> findByProduitAndOf(String prod, String of) {
		// TODO Auto-generated method stub
		return produitRep.findByProduitAndOf(prod, of);
	}

	@Override
	public List<Produits> findByIlot(String ilot) {
		// TODO Auto-generated method stub
		return  produitRep.findByIlot(ilot);
	}

	@Override
	public List<Produits> findByEtat(String etat) {
		// TODO Auto-generated method stub
		return produitRep.findByEtat(etat);
	}

	@Override
	public Produits findById(Integer id) {
		// TODO Auto-generated method stub
		return produitRep.findById(id).orElse(null);
	}

}
