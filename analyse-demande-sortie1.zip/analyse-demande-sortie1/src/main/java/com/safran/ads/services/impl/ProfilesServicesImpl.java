package com.safran.ads.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.safran.ads.entities.Profiles;
import com.safran.ads.model.MessageResponse;
import com.safran.ads.repositories.ProfilesRepositories;
import com.safran.ads.services.ProfilesServices;

@Service
public class ProfilesServicesImpl implements ProfilesServices {

	@Autowired
	private ProfilesRepositories profileRep;
	@Autowired
	 private PasswordEncoder passwordEncoder;
	@Override
	public MessageResponse save(Profiles profile) {
		boolean exist= profileRep.existsByUsername(profile.getUsername());
		if(exist) {
			return new MessageResponse(false, "USERNAME EXISTENT!!");
		}
		String cryptedPwd = passwordEncoder.encode(profile.getPassword());
		profile.setPassword(cryptedPwd);
		profileRep.save(profile);
		return new MessageResponse(true, "Ajout effectuée avec success");
	}

	@Override
	public MessageResponse update(Profiles profile) {
		boolean exist = profileRep.existsByUsernameAndId(profile.getUsername(), profile.getId());
		if (!exist) {
			exist = profileRep.existsByUsername(profile.getUsername());
			if (exist) {
				return new MessageResponse(false, "USERNAME EXISTENT");
			}
		}
		profileRep.save(profile);
		return new MessageResponse(true, "modification effectué avec succés");
	}

	@Override
	public MessageResponse delete(Integer id) {
		boolean exist = profileRep.existsById(id);
		if (!exist) {
			return new MessageResponse(false, "user not found");
		}
		profileRep.deleteById(id);
		return new MessageResponse(true, "Suppression effectué avec succés");
	}

	@Override
	public List<Profiles> findAll() {
		// TODO Auto-generated method stub
		return profileRep.findAll();
	}
	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		return profileRep.findOneByUsername(username);
	}

	@Override
	public Profiles findById(Integer id) {
		// TODO Auto-generated method stub
		return profileRep.findById(id).orElse(null);
	}

}
